#!/usr/bin/env python3
# One-shot kupfate homepage image replacement; scope hero image, CSS, PNG only.
from pathlib import Path
from zipfile import ZipFile
from datetime import datetime
import hashlib, re, shutil, struct, sys

root=Path.cwd()
package=root/'kupfate_MR_261019_release.zip'
landing=root/'components'/'Landing.tsx'
css_path=root/'app'/'globals.css'
image_path=root/'public'/'images'/'kupfate_MR_261019.png'
if not all(p.exists() for p in (package,landing,css_path)):
    raise SystemExit('ERROR: ZIP을 F:\\lifecode-deploy에 저장하고 /mnt/f/lifecode-deploy에서 실행하세요.')
with ZipFile(package) as z:
    image=z.read('public/images/kupfate_MR_261019.png')
if image[:8]!=b'\x89PNG\r\n\x1a\n':
    raise SystemExit('ERROR: PNG 원본 형식이 아닙니다.')
w,h=struct.unpack('>II',image[16:24]);assert (w,h)==(789,599), (w,h)
assert hashlib.sha256(image).hexdigest()=='3e1cdc14a4f546f28e89563a9ad02512db14aa61619fe39a339c0e05b377ef38'

old_landing=landing.read_text(encoding='utf-8')
old_css=css_path.read_text(encoding='utf-8')
pattern=r'(<div className="hero-visual" aria-hidden="true"><img src=")[^"]+(" alt="" fetchPriority="high"\s*/></div>)'
new_landing,count=re.subn(pattern,r'\g<1>/images/kupfate_MR_261019.png\g<2>',old_landing)
if count != 1:
    raise SystemExit('ERROR: Landing.tsx의 이미지 구조가 달라졌습니다. 안전하게 중단합니다.')

marker='/* kupfate MR 261019 hero image — preserve original aspect ratio */'
style='''/* kupfate MR 261019 hero image — preserve original aspect ratio */
.hero-stage .hero-visual {
  position:absolute;
  z-index:0;
  inset:0 -54px 0 auto;
  width:min(46%, 520px);
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:visible;
  pointer-events:none;
}
.hero-stage .hero-visual img {
  display:block;
  visibility:visible;
  opacity:1;
  width:100%;
  height:auto;
  max-height:100%;
  object-fit:contain;
  object-position:center;
}
.hero-stage .hero-visual::after {display:none}
.hero-stage .hero-copy {position:relative;z-index:1}
.hero-stage .sf-coordinate,.hero-stage .visual-caption {z-index:1}
@media (max-width:1100px) and (min-width:701px) {
  .hero-stage .hero-visual {right:0;width:min(43%, 460px)}
}
@media (max-width:700px) {
  .hero-stage .hero-visual {
    inset:auto 0 65px 0;
    width:100%;
    max-width:520px;
    margin:0 auto;
  }
  .hero-stage .hero-visual img {width:100%;max-height:310px;object-fit:contain}
}
'''
if marker in old_css:
    before,_,after=old_css.partition(marker)
    # Protect against accidental removal of unrelated CSS after the patch.
    next_marker=after.find('/* END kupfate MR image */')
    if next_marker==-1:
        raise SystemExit('ERROR: 기존 MR 스타일이 불완전해 안전하게 중단합니다.')
    new_css=before+style+'/* END kupfate MR image */'+after[next_marker+len('/* END kupfate MR image */'):]
else:
    new_css=old_css.rstrip()+'\n'+style+'/* END kupfate MR image */\n'

image_old=image_path.read_bytes() if image_path.exists() else None
changes=[(landing,old_landing.encode(),new_landing.encode()),(css_path,old_css.encode(),new_css.encode()),(image_path,image_old,image)]
to_update=[(path,old,new) for path,old,new in changes if old!=new]
if not to_update:
    print('이미 최신 이미지/스타일이 적용되어 있습니다. 추가 변경 없음.')
    sys.exit(0)

backup=root.parent/('kupfate-MR-backup-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir(parents=True,exist_ok=False)
for path,old,new in to_update:
    relative=path.relative_to(root)
    if old is not None:
        dest=backup/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(old)
for path,old,new in to_update:
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(new)
assert '/images/kupfate_MR_261019.png' in landing.read_text()
assert marker in css_path.read_text()
assert 'visibility:visible' in css_path.read_text().split(marker)[-1]
assert image_path.read_bytes()==image
print('적용 성공: ',image_path)
print('이미지 규격: 789 x 599 / 비율 유지 / 최대 너비 520px')
print('수정 파일:',', '.join(str(p.relative_to(root)) for p,_,_ in to_update))
print('백업 경로:',backup)
print('엔진/결제 API 파일 변경 없음')
